// const base_URL = `https://g20api.getster.tech/api/`;
// const baseURL_API = `https://manageapi.getster.tech/api/`;
// const base_URL1 = `http://localhost:3000/`
const base_URL1 = `http://localhost:3000/api/`
export const environment = {
  production: true,

  baseURL: ``,
  // baseURL:`http://localhost:3000/`,



  postingEmptyOuterBagIDInsert:`${base_URL1}empty_bag_app/time-monitoring/get-audit-trail`,


};







