// const base_URL = `https://g20api.getster.tech/api/`;
// const baseURL_API = `https://manageapi.getster.tech/api/`;
// const base_URL1 = `http://localhost:3000/`
const base_URL1 = `http://localhost:3000/api/`
export const environment = {
  production: true,

  baseURL: ``,
  // baseURL:`http://localhost:3000/`,

  // http://localhost:3000/api/empty_bag_app/time-monitoring/check-users-exist-or-not?reg_no=122&f_name=shilpa&dept=software&staff_student=staff

  posting_Users:`${base_URL1}empty_bag_app/time-monitoring/get-audit-trail`,
  check_Users:`${base_URL1}empty_bag_app/time-monitoring/check-users-exist-or-not`,


};







