module.exports = {
    plugins: [
      require('tailwindcss'),
      require('autoprefixer'),
      // Add more plugins if needed
    ],
  };
  